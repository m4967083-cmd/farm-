import { useState } from "react";
import { ClipboardList, Users, Thermometer, Baby, Stethoscope, Pill, Plus, CheckCircle2, Circle, Trash2, CalendarDays, PawPrint, UserPlus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";

type TaskType = "heat" | "birth" | "disease" | "treatment" | "workers";
type Task = {
  id: string;
  title: string;
  type: TaskType;
  date: string;
  worker: string;
  done: boolean;
  doneBy?: string;
};

const typeConfig: Record<TaskType, { label: string; icon: any; color: string; bg: string }> = {
  heat: { label: "فحص حرارة", icon: Thermometer, color: "text-orange-600", bg: "bg-orange-50" },
  birth: { label: "ولادة", icon: Baby, color: "text-pink-600", bg: "bg-pink-50" },
  disease: { label: "مرض", icon: Stethoscope, color: "text-red-600", bg: "bg-red-50" },
  treatment: { label: "علاج", icon: Pill, color: "text-emerald-600", bg: "bg-emerald-50" },
  workers: { label: "عمالة", icon: Users, color: "text-blue-600", bg: "bg-blue-50" },
};

export default function App() {
  const [workers, setWorkers] = useState<string[]>(["أحمد", "محمد", "خالد", "سالم"]);
  const [newWorker, setNewWorker] = useState("");
  const [tasks, setTasks] = useState<Task[]>([
    { id: "1", title: "فحص حرارة النعاج الصباحي", type: "heat", date: "2025-01-15", worker: "أحمد", done: false },
    { id: "2", title: "متابعة ولادة النعجة رقم 12", type: "birth", date: "2025-01-15", worker: "محمد", done: false },
    { id: "3", title: "علاج التهاب الضرع", type: "treatment", date: "2025-01-14", worker: "خالد", done: true, doneBy: "خالد" },
  ]);
  const [newTask, setNewTask] = useState({ title: "", type: "heat" as TaskType, date: "", worker: "" });
  const [activeTab, setActiveTab] = useState("all");

  const addWorker = () => {
    if (!newWorker.trim() || workers.includes(newWorker.trim())) return;
    setWorkers([...workers, newWorker.trim()]);
    setNewWorker("");
  };

  const addTask = () => {
    if (!newTask.title.trim()) return;
    setTasks([
      { id: Date.now().toString(), ...newTask, done: false },
      ...tasks,
    ]);
    setNewTask({ title: "", type: "heat", date: "", worker: "" });
  };

  const toggleTask = (id: string) => {
    setTasks(tasks.map((t) => (t.id === id ? { ...t, done: !t.done, doneBy: !t.done ? t.worker || workers[0] : undefined } : t)));
  };

  const deleteTask = (id: string) => {
    setTasks(tasks.filter((t) => t.id !== id));
  };

  const filteredTasks = tasks.filter((t) => activeTab === "all" || t.type === activeTab);
  const pendingCount = tasks.filter((t) => !t.done).length;
  const doneCount = tasks.length - pendingCount;

  return (
    <div className="min-h-screen bg-gradient-to-b from-emerald-50 via-white to-white">
      <div className="mx-auto max-w-5xl px-4 py-8">
        {/* Header */}
        <div className="mb-8 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-emerald-600 shadow-lg shadow-emerald-200">
              <PawPrint className="h-6 w-6 text-white" />
            </div>
            <div>
              <h1 className="font-serif text-2xl font-bold text-emerald-900">مزرعة الأغنام</h1>
              <p className="text-sm text-muted-foreground">نظام متابعة المهام والإجراءات اليومية</p>
            </div>
          </div>
          <div className="flex gap-3">
            <div className="rounded-xl bg-emerald-100 px-4 py-2 text-center">
              <div className="text-2xl font-bold text-emerald-700">{pendingCount}</div>
              <div className="text-xs text-emerald-600">مهام معلقة</div>
            </div>
            <div className="rounded-xl bg-blue-100 px-4 py-2 text-center">
              <div className="text-2xl font-bold text-blue-700">{doneCount}</div>
              <div className="text-xs text-blue-600">مهام منجزة</div>
            </div>
          </div>
        </div>

        {/* Add Worker */}
        <Card className="mb-6 border-blue-100 bg-white/80 shadow-md backdrop-blur">
          <CardContent className="p-6">
            <div className="flex items-end gap-4">
              <div className="flex-1">
                <Label htmlFor="new-worker">إضافة عامل جديد</Label>
                <Input
                  id="new-worker"
                  placeholder="اكتب اسم العامل..."
                  value={newWorker}
                  onChange={(e) => setNewWorker(e.target.value)}
                  onKeyDown={(e) => e.key === "Enter" && addWorker()}
                  className="mt-1.5"
                />
              </div>
              <Button onClick={addWorker} className="bg-blue-600 hover:bg-blue-700">
                <UserPlus className="ml-2 h-4 w-4" />
                إضافة عامل
              </Button>
            </div>
            {workers.length > 0 && (
              <div className="mt-3 flex flex-wrap gap-2">
                {workers.map((w) => (
                  <Badge key={w} variant="secondary" className="bg-blue-50 text-blue-700">
                    <Users className="ml-1 h-3 w-3" />
                    {w}
                  </Badge>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Add Task Form */}
        <Card className="mb-6 border-emerald-100 bg-white/80 shadow-md backdrop-blur">
          <CardContent className="p-6">
            <div className="grid gap-4 md:grid-cols-[1fr_180px_180px_180px_auto]">
              <div>
                <Label htmlFor="task-title">المهمة أو الإجراء</Label>
                <Input
                  id="task-title"
                  placeholder="مثال: فحص حرارة النعاج، متابعة ولادة..."
                  value={newTask.title}
                  onChange={(e) => setNewTask({ ...newTask, title: e.target.value })}
                  className="mt-1.5"
                />
              </div>
              <div>
                <Label>النوع</Label>
                <Select value={newTask.type} onValueChange={(v) => setNewTask({ ...newTask, type: v as TaskType })}>
                  <SelectTrigger className="mt-1.5">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {Object.entries(typeConfig).map(([key, config]) => (
                      <SelectItem key={key} value={key}>
                        {config.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>اسم العامل</Label>
                <Select value={newTask.worker} onValueChange={(v) => setNewTask({ ...newTask, worker: v })}>
                  <SelectTrigger className="mt-1.5">
                    <SelectValue placeholder="اختر العامل" />
                  </SelectTrigger>
                  <SelectContent>
                    {workers.map((w) => (
                      <SelectItem key={w} value={w}>
                        {w}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>التاريخ</Label>
                <Input
                  type="date"
                  value={newTask.date}
                  onChange={(e) => setNewTask({ ...newTask, date: e.target.value })}
                  className="mt-1.5"
                />
              </div>
              <div className="flex items-end">
                <Button onClick={addTask} className="w-full bg-emerald-600 hover:bg-emerald-700 md:w-auto">
                  <Plus className="ml-2 h-4 w-4" />
                  إضافة
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Tasks List */}
        <Card className="border-emerald-100 shadow-md">
          <CardHeader className="border-b border-emerald-50 pb-4">
            <div className="flex items-center justify-between">
              <div>
                <CardTitle className="flex items-center gap-2 text-lg text-emerald-900">
                  <ClipboardList className="h-5 w-5 text-emerald-600" />
                  قائمة المهام
                </CardTitle>
                <CardDescription>اضغط على المهمة لتسجيل إنجازها</CardDescription>
              </div>
              <Tabs value={activeTab} onValueChange={setActiveTab} className="w-auto">
                <TabsList className="bg-emerald-50">
                  <TabsTrigger value="all">الكل</TabsTrigger>
                  {Object.entries(typeConfig).map(([key, config]) => (
                    <TabsTrigger key={key} value={key}>
                      {config.label}
                    </TabsTrigger>
                  ))}
                </TabsList>
              </Tabs>
            </div>
          </CardHeader>
          <CardContent className="p-0">
            {filteredTasks.length === 0 ? (
              <div className="flex flex-col items-center justify-center py-16 text-center">
                <div className="mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-emerald-50">
                  <PawPrint className="h-8 w-8 text-emerald-300" />
                </div>
                <p className="text-lg font-medium text-muted-foreground">لا توجد مهام</p>
                <p className="text-sm text-muted-foreground">أضف مهمة جديدة من الأعلى</p>
              </div>
            ) : (
              <div className="divide-y divide-emerald-50">
                {filteredTasks.map((task) => {
                  const config = typeConfig[task.type];
                  const Icon = config.icon;
                  return (
                    <div
                      key={task.id}
                      className={cn(
                        "group flex items-center gap-4 px-6 py-4 transition-colors hover:bg-emerald-50/50",
                        task.done && "bg-emerald-50/30"
                      )}
                    >
                      <button
                        onClick={() => toggleTask(task.id)}
                        className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full transition-all hover:scale-110"
                      >
                        {task.done ? (
                          <CheckCircle2 className="h-7 w-7 text-emerald-500" />
                        ) : (
                          <Circle className="h-7 w-7 text-slate-300 transition-colors group-hover:text-emerald-400" />
                        )}
                      </button>
                      <div className={cn("flex h-10 w-10 shrink-0 items-center justify-center rounded-xl", config.bg)}>
                        <Icon className={cn("h-5 w-5", config.color)} />
                      </div>
                      <div className="min-w-0 flex-1">
                        <p className={cn("truncate font-medium", task.done && "text-muted-foreground line-through")}>
                          {task.title}
                        </p>
                        <div className="mt-1 flex items-center gap-2 text-xs text-muted-foreground">
                          <Badge variant="secondary" className={cn("border-0", config.bg, config.color)}>
                            {config.label}
                          </Badge>
                          {task.worker && (
                            <span className="flex items-center gap-1 text-blue-600">
                              <Users className="h-3 w-3" />
                              {task.worker}
                            </span>
                          )}
                          {task.date && (
                            <span className="flex items-center gap-1">
                              <CalendarDays className="h-3 w-3" />
                              {task.date}
                            </span>
                          )}
                          {task.doneBy && (
                            <span className="flex items-center gap-1 text-emerald-600">
                              <CheckCircle2 className="h-3 w-3" />
                              أنجزها: {task.doneBy}
                            </span>
                          )}
                        </div>
                      </div>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => deleteTask(task.id)}
                        className="opacity-0 transition-opacity group-hover:opacity-100"
                      >
                        <Trash2 className="h-4 w-4 text-red-400 hover:text-red-600" />
                      </Button>
                    </div>
                  );
                })}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}